#!/usr/bin/env python
import sys


def main():
    sys.exit(
        "You're using an outdated location for the get-pip.py script, please "
        "use the one available from https://bootstrap.pypa.io/get-pip.py"
    )


if __name__ == "__main__":
    main()
